export { default } from './SearchInput'
